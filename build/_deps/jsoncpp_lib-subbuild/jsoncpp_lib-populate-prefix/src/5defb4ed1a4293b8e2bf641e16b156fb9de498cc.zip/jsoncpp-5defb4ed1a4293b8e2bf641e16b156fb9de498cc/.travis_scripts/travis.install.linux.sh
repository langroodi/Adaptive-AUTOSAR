set -vex

pip3 install --user meson ninja
which meson
which ninja
